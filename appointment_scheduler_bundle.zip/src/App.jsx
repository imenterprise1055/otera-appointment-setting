import React, { useEffect, useMemo, useState } from "react";
import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import timeGridPlugin from "@fullcalendar/timegrid";
import interactionPlugin from "@fullcalendar/interaction";

// Simple list of planners; adapt or load dynamically
const DEFAULT_PLANNERS = ["Alice", "Bob", "Charlie", "Dana"];

// Utilities
const storageKey = "appointments_v1";
const todayDateKey = (d = new Date()) => d.toISOString().slice(0, 10);

function loadAppointments() {
  try {
    const raw = localStorage.getItem(storageKey);
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    console.error(e);
    return [];
  }
}

function saveAppointments(list) {
  localStorage.setItem(storageKey, JSON.stringify(list));
}

export default function App() {
  const [planners, setPlanners] = useState(DEFAULT_PLANNERS);
  const [appointments, setAppointments] = useState(() => loadAppointments());
  const [filterPlanner, setFilterPlanner] = useState("");
  const [form, setForm] = useState({ client: "", planner: DEFAULT_PLANNERS[0], date: "", time: "09:00", notes: "" });

  useEffect(() => saveAppointments(appointments), [appointments]);

  // Add appointment
  function handleSubmit(e) {
    e.preventDefault();
    if (!form.client || !form.date || !form.time) return;
    const iso = new Date(`${form.date}T${form.time}`);
    const appt = {
      id: Math.random().toString(36).slice(2, 9),
      title: `${form.client} (${form.planner})`,
      client: form.client,
      planner: form.planner,
      start: iso.toISOString(),
      notes: form.notes,
    };
    setAppointments(prev => [...prev, appt].sort((a,b)=> new Date(a.start)-new Date(b.start)));
    setForm({ client: "", planner: planners[0] || "", date: "", time: "09:00", notes: "" });
  }

  // Remove appointment
  function removeAppointment(id) {
    if (!confirm("Delete this appointment?")) return;
    setAppointments(prev => prev.filter(a => a.id !== id));
  }

  // Leaderboard: counts per planner for a chosen day
  const [leaderboardDate, setLeaderboardDate] = useState(todayDateKey());
  const leaderboard = useMemo(() => {
    const counts = {};
    planners.forEach(p => counts[p] = 0);
    appointments.forEach(a => {
      const day = a.start.slice(0,10);
      if (day === leaderboardDate) counts[a.planner] = (counts[a.planner] || 0) + 1;
    });
    // Convert to sorted array
    return Object.entries(counts).map(([planner, count])=>({planner, count})).sort((a,b)=>b.count-a.count||a.planner.localeCompare(b.planner));
  }, [appointments, planners, leaderboardDate]);

  // Events for FullCalendar (apply planner filter)
  const events = useMemo(() => {
    return appointments
      .filter(a => !filterPlanner || a.planner === filterPlanner)
      .map(a => ({ id: a.id, title: a.title, start: a.start }))
  }, [appointments, filterPlanner]);

  // Quick add by clicking calendar
  function handleDateSelect(selectInfo) {
    const dateStr = selectInfo.startStr.slice(0,10);
    setForm(prev => ({ ...prev, date: dateStr }));
    // optionally open a modal — here we just populate the form date
  }

  return (
    <div className="min-h-screen p-6 font-sans" style={{fontFamily: 'Inter, system-ui, sans-serif'}}>
      <h1 className="text-2xl font-semibold mb-4">Appointment Scheduler — Prototype</h1>
      <div className="grid md:grid-cols-3 gap-6">
        {/* Form column */}
        <div className="col-span-1 bg-white rounded-2xl p-4 shadow-sm">
          <h2 className="font-medium mb-2">New appointment</h2>
          <form onSubmit={handleSubmit} className="space-y-3">
            <div>
              <label className="block text-sm">Client</label>
              <input value={form.client} onChange={e=>setForm({...form, client: e.target.value})} className="w-full border rounded p-2" />
            </div>
            <div>
              <label className="block text-sm">Planner</label>
              <select value={form.planner} onChange={e=>setForm({...form, planner: e.target.value})} className="w-full border rounded p-2">
                {planners.map(p=> <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
            <div className="flex gap-2">
              <div>
                <label className="block text-sm">Date</label>
                <input type="date" value={form.date} onChange={e=>setForm({...form, date: e.target.value})} className="border rounded p-2" />
              </div>
              <div>
                <label className="block text-sm">Time</label>
                <input type="time" value={form.time} onChange={e=>setForm({...form, time: e.target.value})} className="border rounded p-2" />
              </div>
            </div>
            <div>
              <label className="block text-sm">Notes</label>
              <textarea value={form.notes} onChange={e=>setForm({...form, notes: e.target.value})} className="w-full border rounded p-2" rows={3} />
            </div>
            <div className="flex gap-2">
              <button className="px-4 py-2 rounded bg-blue-600 text-white">Add</button>
              <button type="button" onClick={()=>{const name = prompt('New planner name'); if(name) setPlanners(prev=>[...prev,name]);}} className="px-4 py-2 rounded border">Add planner</button>
            </div>
          </form>

          <hr className="my-4" />

          <div>
            <h3 className="font-medium">Filter / Quick actions</h3>
            <select value={filterPlanner} onChange={e=>setFilterPlanner(e.target.value)} className="w-full border rounded p-2 mt-2">
              <option value="">-- show all planners --</option>
              {planners.map(p=> <option key={p} value={p}>{p}</option>)}
            </select>
            <div className="mt-3 text-sm">
              <button onClick={()=>{localStorage.removeItem(storageKey); setAppointments([])}} className="text-red-600">Clear all appointments</button>
            </div>
          </div>
        </div>

        {/* Calendar column */}
        <div className="md:col-span-2 bg-white rounded-2xl p-4 shadow-sm">
          <h2 className="font-medium mb-2">Agenda / Calendar</h2>
          <FullCalendar
            plugins={[ dayGridPlugin, timeGridPlugin, interactionPlugin ]}
            initialView="timeGridWeek"
            selectable={true}
            editable={false}
            events={events}
            height={600}
            select={handleDateSelect}
            eventClick={(info)=>{
              const id = info.event.id;
              const appt = appointments.find(a=>a.id===id);
              if(!appt) return;
              if(confirm(`Open details for ${appt.client} (planner: ${appt.planner})?\\n\\nDelete this appointment?`)){
                removeAppointment(id);
              }
            }}
          />

          <div className="mt-4">
            <h3 className="font-medium">Upcoming (filtered)</h3>
            <ul className="divide-y mt-2">
              {events.slice(0,10).map(ev=>{
                const a = appointments.find(x=>x.id===ev.id);
                return <li key={ev.id} className="py-2 flex justify-between items-center">
                  <div>
                    <div className="font-semibold">{a.client}</div>
                    <div className="text-xs">{new Date(a.start).toLocaleString()} — {a.planner}</div>
                  </div>
                  <div>
                    <button onClick={()=>removeAppointment(a.id)} className="text-red-600 text-sm">Delete</button>
                  </div>
                </li>
              })}
            </ul>
          </div>
        </div>

        {/* Leaderboard column */}
        <div className="col-span-3 bg-white rounded-2xl p-4 shadow-sm">
          <h2 className="font-medium mb-2">Leaderboard — Appointments per planner</h2>
          <div className="flex gap-3 items-center mb-3">
            <label className="text-sm">Date</label>
            <input type="date" value={leaderboardDate} onChange={e=>setLeaderboardDate(e.target.value)} className="border rounded p-2" />
            <div className="ml-auto text-sm">Total appointments: {appointments.length}</div>
          </div>

          <ol className="list-decimal pl-5">
            {leaderboard.map(row=> (
              <li key={row.planner} className="py-1 flex justify-between">
                <div>{row.planner}</div>
                <div className="font-semibold">{row.count}</div>
              </li>
            ))}
          </ol>
        </div>
      </div>

    </div>
  );
}
