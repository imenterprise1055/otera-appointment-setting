// Apps Script for Google Form -> Calendar -> Leaderboard
// Paste this into Extensions -> Apps Script in your Google Sheet linked to the form.

const TARGET_CALENDAR_ID = ''; // use '' for default calendar, or put calendar ID

function onOpen() {
  SpreadsheetApp.getUi().createMenu('Scheduler')
    .addItem('Rebuild leaderboard', 'rebuildLeaderboard')
    .addToUi();
}

function onFormSubmit(e) {
  try {
    const named = e.namedValues || {};
    const client = named['Client Name'] ? named['Client Name'][0] : (e.values[1] || 'Client');
    const date = named['Date'] ? named['Date'][0] : e.values[2];
    const time = named['Time'] ? named['Time'][0] : e.values[3];
    const planner = named['Planner'] ? named['Planner'][0] : e.values[4];
    const notes = named['Notes'] ? named['Notes'][0] : '';

    const start = new Date(date + ' ' + time);
    const end = new Date(start.getTime() + 30*60*1000);

    const cal = TARGET_CALENDAR_ID ? CalendarApp.getCalendarById(TARGET_CALENDAR_ID) : CalendarApp.getDefaultCalendar();
    cal.createEvent(`${client} (${planner})`, start, end, {description: notes});

    rebuildLeaderboard();
  } catch (err) {
    Logger.log('Error onFormSubmit: ' + err);
  }
}

function rebuildLeaderboard() {
  const ss = SpreadsheetApp.getActive();
  const responses = ss.getSheetByName('FormResponses');
  const lb = ss.getSheetByName('Leaderboard') || ss.insertSheet('Leaderboard');

  const data = responses.getDataRange().getValues();
  const headers = data.shift();
  const idxClient = headers.indexOf('Client Name');
  const idxDate = headers.indexOf('Date');
  const idxTime = headers.indexOf('Time');
  const idxPlanner = headers.indexOf('Planner');
  if (idxPlanner < 0) {
    lb.clear().getRange(1,1).setValue('Please ensure a "Planner" column exists in the form responses.');
    return;
  }

  const counts = {};
  const plannersSet = new Set();
  data.forEach(row => {
    const date = row[idxDate];
    const planner = row[idxPlanner];
    if (!date || !planner) return;
    const d = new Date(date);
    const day = Utilities.formatDate(d, Session.getScriptTimeZone(), 'yyyy-MM-dd');
    plannersSet.add(planner);
    counts[day] = counts[day] || {};
    counts[day][planner] = (counts[day][planner] || 0) + 1;
  });

  const planners = Array.from(plannersSet).sort();
  const out = [];
  const headerRow = ['Date', ...planners];
  out.push(headerRow);

  const days = Object.keys(counts).sort();
  days.forEach(day => {
    const row = [day];
    planners.forEach(p => row.push(counts[day][p] || 0));
    out.push(row);
  });

  lb.clear();
  if (out.length === 1) {
    lb.getRange(1,1).setValue('No appointments yet.');
  } else {
    lb.getRange(1,1,out.length,out[0].length).setValues(out);
  }
}
