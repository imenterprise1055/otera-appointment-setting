Google Forms + Sheets + Apps Script — Package
=============================================

What you get
------------
- apps_script.js : Paste this into Extensions -> Apps Script in your Google Sheet linked to the form.
- Step-by-step instructions (below).

Steps
-----
1) Create a Google Form with fields:
   - Client Name (Short answer)
   - Date (Date)
   - Time (Time)
   - Planner (Dropdown) -- add planners here
   - Notes (Paragraph)

2) Link form responses to a Google Sheet (Responses -> Link to Sheets).
   Rename the sheet tab containing responses to 'FormResponses' (or update the script).

3) Open Extensions -> Apps Script in that Sheet, delete any default code, and paste the contents of apps_script.js.

4) In Apps Script: Save. Then create a Trigger:
   - Function: onFormSubmit
   - Event source: From spreadsheet
   - Event type: On form submit
   Also create a time-driven trigger for rebuildLeaderboard if you want scheduled updates.

5) Optionally set TARGET_CALENDAR_ID in the script to a specific calendar ID, or leave '' to use your default calendar.

6) Use the 'Leaderboard' tab (script will create it) to see counts per planner per day.

Helpful links:
- Google Forms guide: https://support.google.com/docs/answer/6281888
- Apps Script triggers: https://developers.google.com/apps-script/guides/triggers/installable
- How to find Calendar ID: Calendar settings -> Integrate calendar -> Calendar ID
